webpackJsonp([21],{

/***/ 308:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
// wx-action-sheet-item
exports.default = window.exparser.registerElement({
  is: 'wx-action-sheet-item',
  template: '\n    <slot></slot>\n  ',
  properties: {},
  behaviors: ['wx-base']
});

/***/ })

});